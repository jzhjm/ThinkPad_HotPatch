# Lenovo-T420-Clover

This repo contains the files and scripts to install macOS on the Lenovo T420 family

Refer to this Guide for the details: http://www.insanelymac.com/forum/topic/285678-lenovo-thinkpad-t420-with-uefi-only/page-25#entry1952283
